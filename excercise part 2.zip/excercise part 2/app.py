from flask import Flask, render_template, url_for, request

app = Flask(__name__)

events_list =[
    {'title': 'Mysore Masti', 'year':2024, 'location':'Mysore'},
    {'title': 'Bengalore Masti', 'year':2023, 'location': 'Bengalore'},
    {'title': 'Pune Masti', 'year':2025, 'location':'Pune'},
    {'title': 'Hyderabad', 'year':2022, 'location':'Hyderabad'}
]

@app.route('/events')
def show_events():
    return render_template('events.html', events = events_list)

@app.route('/events/<loc>')
def view_events_by_location(loc):
    lst = []
    for event in events_list:
        if event['location'].lower() == loc:
            lst.append(event)
    return render_template('events.html', events= lst)

@app.route('/events/<int:year>')
def view_events_from(year):
    lst = []
    for event in events_list:
        if event['year'] == year:
            lst.append(event)
    return render_template('events.html', events = lst)

@app.route('/events/<loc>/<int:year>')
def view_events_from_location_year(loc, year):
    lst =[]
    for event in events_list:
        if event['year'] == year and event['location'] == loc:
            lst.append(event)
    return render_template('events.html', events = lst)

@app.route('/add-event', methods = ['GET', 'POST'])
def delete_events():
    if request.method == 'POST':
        events_title = request.form.get('event_name')
        location = request.form.get('location')
        year = request.form.get('year')

        events_dict = {'title':events_title, 'year':year, 'location': location}
        events_list.append(events_dict)
        print(events_list)
        return render_template('events.html', events = events_list)
    
    if request.method == 'GET':
        return render_template('add_event.html', events = events_list)
    

@app.route('/delete-event', methods = ['GET', 'POST'])
def add_events():
    if request.method == 'POST':
        events_title = request.form.get('event_name')
        location = request.form.get('location')
        year = request.form.get('year')

        events_dict = {'title':events_title, 'year':year, 'location': location}
        for event in events_list:
            if event['title'] ==events_dict['title']:
                events_list.pop(event['title'])

        print(events_list)

        return render_template('events.html', events = events_list)
    if request.method == 'GET':
        return render_template('add_event.html', events = events_list)

if __name__ == "__main__":
    app.run(debug=True)