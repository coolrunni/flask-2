from flask import Flask, render_template, request, url_for
from datetime import date

app = Flask(__name__)

# Sample events data based on location and year
events_data = {
    "us": {
        2021: [
            {
                "title": "DC Hackathon",
                "date": "2021-09-12 09:00:00",
                "organizer": "John Mathew",
                "image": "../static/images/event.jpg"
            }
        ]
    },
    "uk": {
        2022: [
            {
                "title": "DRR Camp",
                "date": "2022-01-05 11:30:00",
                "organizer": "Ben Fedrick",
                "image": "../static/images/event.jpg"
            }
        ],
        2021: [
            {
                "title": "Designing Webinar",
                "date": "2021-10-11 14:30:00",
                "organizer": "John Mathew",
                "image": "../static/images/event.jpg"
            }
        ]
    }
}

# Route for displaying and filtering events
@app.route('/events', methods=['GET'])
def view_events():
    location = request.args.get('location')
    year = request.args.get('year')

    if location and year:
        return view_events_by_location_year(location, year)
    elif location:
        return view_events_from_location(location)
    elif year:
        return view_events_by_year(year)
    else:
        return render_template('events.html')

# View function for filtering by location alone
@app.route('/events/location/<location>')
def view_events_from_location(location):
    events = [f"Sample event at {location}"]  # Replace with actual query logic
    return render_template('events.html', loc= location)

# View function for filtering by year alone
@app.route('/events/year/<int:year>')
def view_events_by_year(year):
    events = [f"Sample event in {year}"]  # Replace with actual query logic
    return render_template('events.html', year = year)

# View function for filtering by both location and year
@app.route('/events/view-by-<location>-<year>')
def view_events_by_location_year(location, year):
    year = int(year)
    # Retrieve events based on location and year from events_data
    events = events_data.get(location, {}).get(year, [])
    loc_display = location.upper() if events else "No events found"
    
    return render_template('events.html', year=year, loc=loc_display)

# Adding new event details
@app.route('/events/add', methods=['GET', 'POST'])
def add_event():
    if request.method == 'POST':
        pass
    return render_template('add_event.html')

# Editing existing event details
@app.route('/events/edit/<int:event_id>', methods=['GET', 'POST'])
def edit_event(event_id):
    if request.method == 'POST':
        pass
    return render_template('edit_event.html', event_id=event_id)

# Deleting existing event details
@app.route('/events/delete/<int:event_id>', methods=['POST'])
def delete_event(event_id):
    # Logic to delete event
    return render_template('delete_event.html', event_id=event_id)
